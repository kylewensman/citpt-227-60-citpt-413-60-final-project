# php_crud_api_forBonsai

This is a fork of the repository, PHP Crud API by mevdschee (url: https://github.com/mevdschee/php-crud-api)

Students, to use this, upload the file to the Bonsai web server. Change the bottom few lines to include your username, password, database name, and the URL for the server. Contact me in class to see how to do this.
